DOT SNAKE — Android game project (updated)

Native Java Snake game with swipe controls and neon dot styling.
Updates in this version:
- Larger snake/food grid cells for a bigger-looking snake.
- No wall collision: the snake wraps around the screen edges.
- Many glowing food dots in orange, green, purple, cyan, and yellow.
- Eat food to gain 10 points; snake grows as it eats.
- Swipe up/down/left/right anywhere in the game field to steer.
- Tap to start/restart; tap during play to pause.
- Top system status bar and bottom navigation/gesture bar spacing.

Build with AndroidForge:
1. Upload DotSnakeGame_Project.zip.
2. Choose Android (APK), leave Force-install NDK unchecked.
3. Build and install the APK.

Package: com.example.dotsnake
Min Android: 6.0 (API 23)
