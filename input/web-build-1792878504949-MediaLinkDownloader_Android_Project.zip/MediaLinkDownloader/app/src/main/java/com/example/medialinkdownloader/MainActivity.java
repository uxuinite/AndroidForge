package com.example.medialinkdownloader;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.app.DownloadManager;
import android.database.Cursor;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.widget.*;
import java.util.*;
import java.io.File;

public class MainActivity extends Activity {
    int navy=Color.rgb(8,27,55), blue=Color.rgb(0,112,255), purple=Color.rgb(126,55,255);
    int ink=Color.rgb(20,31,52), pale=Color.rgb(242,246,252), muted=Color.rgb(100,116,145);
    LinearLayout root, body, nav; EditText linkInput; String page="Home";
    ArrayList<String> queue=new ArrayList<>(), completed=new ArrayList<>();
    int downloadsStarted=0;
    public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(navy); getWindow().setNavigationBarColor(Color.WHITE); show("Home");}
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void pad(View v,int a,int b,int c,int d){v.setPadding(dp(a),dp(b),dp(c),dp(d));}
    TextView button(String s,int color,Runnable action){TextView t=text(s,14,Color.WHITE,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(12),dp(13),dp(12),dp(13));t.setBackground(bg(color,16));t.setOnClickListener(v->action.run());return t;}
    void show(String p){page=p; root=col();root.setBackgroundColor(pale);setContentView(root);
        ScrollView scroll=new ScrollView(this); body=col();pad(body,18,18,18,12);scroll.addView(body,new ScrollView.LayoutParams(-1,-2));root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if(p.equals("Home"))home();else if(p.equals("Video"))video();else if(p.equals("Music"))music();else if(p.equals("Process"))process();else storage();
        makeNav();
    }
    void header(String title,String sub){TextView h=text(title,27,ink,true);body.addView(h);TextView s=text(sub,14,muted,false);body.addView(s);space(body,14);}
    void space(LinearLayout l,int h){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    void card(LinearLayout parent, View child){LinearLayout c=col();pad(c,14,14,14,14);c.setBackground(bg(Color.WHITE,22));c.addView(child);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(12);parent.addView(c,lp);}
    void home(){
        header("Good morning ☀️","Your all-in-one video & music downloader");
        LinearLayout hero=col();pad(hero,18,18,18,18);hero.setBackground(bg(navy,24));
        TextView ht=text("Download Videos\n& Music from Any Link",24,Color.WHITE,true);hero.addView(ht);
        TextView platforms=text("YouTube  ·  Facebook  ·  TikTok / 抖音",13,Color.LTGRAY,false);hero.addView(platforms);space(hero,12);
        card(body,hero);
        inputCard();
        LinearLayout platformsRow=row();
        for(String s:new String[]{"▶ YouTube","f Facebook","♪ TikTok","••• More"}){TextView t=text(s,12,ink,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(5),dp(14),dp(5),dp(14));platformsRow.addView(t,new LinearLayout.LayoutParams(0,-2,1));}
        card(body,platformsRow);
        header("Quick tools","Choose what you want to save");
        LinearLayout r=row();r.addView(button("▣  Video",blue,()->show("Video")),new LinearLayout.LayoutParams(0,-2,1));space(r,1);r.addView(button("♫  Music",purple,()->show("Music")),new LinearLayout.LayoutParams(0,-2,1));card(body,r);
        LinearLayout r2=row();r2.addView(button("☷  Process",navy,()->show("Process")),new LinearLayout.LayoutParams(0,-2,1));r2.addView(button("▤  Storage",muted,()->show("Storage")),new LinearLayout.LayoutParams(0,-2,1));card(body,r2);
    }
    void inputCard(){
        LinearLayout c=col();pad(c,12,12,12,12);c.setBackground(bg(Color.WHITE,20));
        linkInput=new EditText(this);linkInput.setSingleLine(true);linkInput.setTextSize(14);linkInput.setHint("Paste link here (YouTube, Facebook, 抖音...)");linkInput.setPadding(dp(12),dp(10),dp(12),dp(10));linkInput.setBackground(bg(pale,14));c.addView(linkInput,new LinearLayout.LayoutParams(-1,dp(50)));
        space(c,10);LinearLayout r=row();r.addView(button("▣ Paste",0xffe8eef7,()->paste()),new LinearLayout.LayoutParams(0,-2,1));((TextView)r.getChildAt(0)).setTextColor(ink);
        TextView dl=button("↓  Download",blue,()->addLink());LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.leftMargin=dp(8);r.addView(dl,lp);c.addView(r);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=dp(14);body.addView(c,cp);
    }
    void paste(){try{ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);ClipData d=cm.getPrimaryClip();if(d!=null&&d.getItemCount()>0)linkInput.setText(d.getItemAt(0).coerceToText(this));}catch(Exception e){}}
    void addLink(){
        String url=linkInput==null?"":linkInput.getText().toString().trim();
        if(url.isEmpty()){Toast.makeText(this,"Paste a video or audio link first",Toast.LENGTH_SHORT).show();return;}
        if(!url.startsWith("https://")&&!url.startsWith("http://")){Toast.makeText(this,"Please enter a valid http/https link",Toast.LENGTH_SHORT).show();return;}
        queue.add(url);Toast.makeText(this,"Added to Process queue",Toast.LENGTH_SHORT).show();linkInput.setText("");show("Process");
    }
    void video(){header("Video","Download video and choose quality");inputCard();chips("All     YouTube     Facebook     TikTok     Others");header("Quality options","Choose your preferred output");for(String s:new String[]{"4K (2160p)  ·  MP4","1440p (2K)  ·  MP4","1080p Full HD  ·  MP4","720p HD  ·  MP4","480p  ·  MP4"}){LinearLayout r=row();r.addView(text(s,15,ink,true),new LinearLayout.LayoutParams(0,-2,1));r.addView(button("↓",blue,()->Toast.makeText(this,"Choose a supported direct media URL to download",Toast.LENGTH_LONG).show()));card(body,r);}}
    void music(){header("Music","Extract or save audio");inputCard();chips("MP3     M4A     WAV     FLAC     OGG");for(String s:new String[]{"320 kbps  ·  High Quality","256 kbps  ·  Balanced","192 kbps  ·  Standard","128 kbps  ·  Small file"}){LinearLayout r=row();r.addView(text(s,15,ink,true),new LinearLayout.LayoutParams(0,-2,1));r.addView(button("↓",purple,()->Toast.makeText(this,"Audio conversion needs a media resolver/converter",Toast.LENGTH_LONG).show()));card(body,r);}}
    void chips(String s){TextView t=text(s,12,navy,true);pad(t,12,12,12,12);t.setBackground(bg(0xffe5edfa,16));body.addView(t);space(body,12);}
    void process(){header("Process","Downloading, converting and completed");
        LinearLayout tabs=row();for(String s:new String[]{"All ("+(queue.size()+completed.size())+")","Downloading","Completed"}){TextView t=text(s,12,ink,true);t.setGravity(Gravity.CENTER);tabs.addView(t,new LinearLayout.LayoutParams(0,dp(42),1));}card(body,tabs);
        if(queue.isEmpty()&&completed.isEmpty()){TextView empty=text("No downloads yet\nPaste a link on Home, Video or Music to add it here.",15,muted,false);pad(empty,12,28,12,28);card(body,empty);}
        for(String url:queue){LinearLayout item=col();item.addView(text("⬇  "+shortUrl(url),15,ink,true));item.addView(text("Waiting in queue  ·  Ready when supported",12,muted,false));space(item,8);ProgressBar pb=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);pb.setProgress(0);item.addView(pb);space(item,8);item.addView(button("Try direct download",blue,()->downloadDirect(url)));card(body,item);}
        for(String f:completed){LinearLayout item=col();item.addView(text("✓  "+f,15,ink,true));item.addView(text("Completed",12,0xff14804a,false));card(body,item);}
        TextView note=text("Note: platform page links require a compliant resolver. Direct .mp4/.mp3 URLs can be downloaded by Android Download Manager.",12,muted,false);body.addView(note);
    }
    String shortUrl(String s){return s.length()>44?s.substring(0,41)+"...":s;}
    void downloadDirect(String url){
        String low=url.toLowerCase(Locale.ROOT);
        if(!(low.contains(".mp4")||low.contains(".mp3")||low.contains(".m4a")||low.contains(".webm")||low.contains(".wav")||low.contains(".mov"))){Toast.makeText(this,"This looks like a platform page, not a direct media file. A resolver service is needed.",Toast.LENGTH_LONG).show();return;}
        try{DownloadManager.Request req=new DownloadManager.Request(Uri.parse(url));req.setTitle("MediaLink download");req.setDescription("Downloading media");req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "MediaLink_"+System.currentTimeMillis()+guessExt(low));((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(req);queue.remove(url);completed.add("MediaLink_"+(completed.size()+1)+guessExt(low));Toast.makeText(this,"Download started in Android Download Manager",Toast.LENGTH_LONG).show();show("Process");}catch(Exception e){Toast.makeText(this,"Could not start download: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    String guessExt(String s){for(String e:new String[]{".mp4",".mp3",".m4a",".webm",".wav",".mov"})if(s.contains(e))return e;return ".bin";}
    void storage(){header("Storage","Manage your downloaded files");File d=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);long total=0;try{if(d.exists())for(File f:d.listFiles())if(f.isFile())total+=f.length();}catch(Exception e){}
        LinearLayout summary=col();summary.addView(text("Downloads folder",17,ink,true));summary.addView(text(d.getAbsolutePath(),12,muted,false));space(summary,8);summary.addView(text("Files found: "+(d.exists()&&d.listFiles()!=null?d.listFiles().length:0),14,blue,true));summary.addView(text("Used by visible files: "+android.text.format.Formatter.formatFileSize(this,total),14,muted,false));card(body,summary);
        body.addView(text("Recent files",18,ink,true));space(body,8);
        File[] list=d.listFiles();if(list!=null){Arrays.sort(list,(a,b)->Long.compare(b.lastModified(),a.lastModified()));int count=0;for(File f:list){if(!f.isFile())continue;LinearLayout r=row();r.addView(text(iconFor(f.getName())+"  "+f.getName(),14,ink,true),new LinearLayout.LayoutParams(0,-2,1));r.addView(text(android.text.format.Formatter.formatFileSize(this,f.length()),11,muted,false));card(body,r);if(++count>=30)break;}}
        if(list==null||list.length==0)card(body,text("Your downloaded files will appear here.",14,muted,false));
        body.addView(button("Open Android Downloads",blue,()->{try{Intent i=new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS);startActivity(i);}catch(Exception e){Toast.makeText(this,"Open the Files app to view Downloads",Toast.LENGTH_SHORT).show();}}));
    }
    String iconFor(String n){String x=n.toLowerCase(Locale.ROOT);if(x.endsWith(".mp3")||x.endsWith(".m4a")||x.endsWith(".wav"))return "♫";if(x.endsWith(".mp4")||x.endsWith(".mov")||x.endsWith(".webm"))return "▶";return "▤";}
    void makeNav(){nav=row();nav.setBackgroundColor(Color.WHITE);String[] labels={"Home","Video","Music","Process","Storage"};String[] icons={"⌂","▣","♫","☷","▤"};for(int i=0;i<labels.length;i++){final String dest=labels[i];LinearLayout cell=col();cell.setGravity(Gravity.CENTER);TextView ic=text(icons[i],19,page.equals(dest)?blue:muted,true);ic.setGravity(Gravity.CENTER);TextView tx=text(labels[i],10,page.equals(dest)?blue:muted,page.equals(dest));tx.setGravity(Gravity.CENTER);cell.addView(ic);cell.addView(tx);cell.setPadding(0,dp(8),0,dp(8));cell.setOnClickListener(v->show(dest));nav.addView(cell,new LinearLayout.LayoutParams(0,-2,1));}root.addView(nav);}
}
