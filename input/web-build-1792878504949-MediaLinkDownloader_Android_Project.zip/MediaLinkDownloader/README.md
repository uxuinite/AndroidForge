# MediaLink Downloader — Android Studio project

A native Java Android starter project inspired by the requested UI concept. It includes five bottom tabs:
- **Home** — paste link, paste-from-clipboard, quick tools and platform shortcuts
- **Video** — link entry and quality choices
- **Music** — link entry and audio-quality choices
- **Process** — queued items, completed items and direct-download attempt
- **Storage** — scans the public Downloads folder and lists recent files

## Open and build
1. Extract this ZIP.
2. Open the `MediaLinkDownloader` folder in Android Studio.
3. Let Gradle sync (Android Studio JDK 17 recommended).
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Important limitation
This is a **starter UI/project**, not a finished universal downloader. Android's DownloadManager can fetch direct media-file URLs such as an authorized `.mp4` or `.mp3` URL, but a normal YouTube, Facebook, TikTok or Douyin page URL is not itself a media file. Platform-specific link resolution, audio extraction/conversion, thumbnail metadata, robust parallel queues, and per-platform compliance must be implemented separately using permitted APIs or a backend. Do not use this app to bypass access controls or download content without permission.

The project has not been compiled or tested on a device in this environment. Android Studio may request SDK/Gradle setup on first open.
