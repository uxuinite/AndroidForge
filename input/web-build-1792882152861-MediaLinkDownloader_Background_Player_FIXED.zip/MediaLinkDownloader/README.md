# MediaLink Downloader — AndroidForge source ZIP

## Included in this revision
- Dark navy/blue/purple MediaLink interface with Home, Video, Music, Process, and Storage tabs.
- Lists local media files found in public Music, Movies, and Downloads folders (after media permission is granted).
- Music playback through an Android foreground media service, with notification/lock-screen play, pause, previous, next, playlist continuation, repeat-all by default, and repeat-one support via media session.
- Music sleep timer buttons (30/60/90 minutes).
- Direct audio-file URL downloads using Android DownloadManager.
- Direct media link queue UI and basic storage listing.

## Important limitations
- This is an Android Studio/AndroidForge **source project ZIP**, not a prebuilt APK. It must be built in AndroidForge/GitHub Actions before installing. This environment did not run a full Gradle Android build, so the new revision is not compile-verified.
- Direct file URLs are supported; webpage links from YouTube, Facebook, TikTok/Douyin do not automatically resolve to media. A compatible permitted resolver/backend would be a separate feature.
- Tapping a video opens the phone's installed video player. Music has the in-app background media service and lock-screen controls; this revision does not yet implement an in-app video renderer or guarantee video-audio continuation from every external video player.
- The sleep timer is a best-effort app timer; Android/OEM restrictions and other media apps may affect behavior.
- Playback supports files the Android MediaPlayer can decode; codec support varies by phone.

## Build
Upload the ZIP to AndroidForge and run its Android build workflow. If it fails, download the build log artifact and share the error log so the specific failure can be fixed.
