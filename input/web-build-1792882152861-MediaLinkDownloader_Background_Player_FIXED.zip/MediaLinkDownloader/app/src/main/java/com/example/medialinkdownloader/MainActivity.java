package com.example.medialinkdownloader;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Typeface;
import android.net.Uri;
import android.app.DownloadManager;
import android.database.Cursor;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.widget.*;
import java.util.*;
import java.io.File;

public class MainActivity extends Activity {
    int navy=Color.rgb(8,27,55), blue=Color.rgb(0,112,255), purple=Color.rgb(126,55,255);
    int ink=Color.rgb(20,31,52), pale=Color.rgb(242,246,252), muted=Color.rgb(100,116,145);
    LinearLayout root, body, nav; EditText linkInput; String page="Home";
    ArrayList<String> queue=new ArrayList<>(), completed=new ArrayList<>();
    int downloadsStarted=0;
    public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(navy); getWindow().setNavigationBarColor(Color.WHITE); requestMediaPermissions(); show("Home");}
    void requestMediaPermissions(){if(Build.VERSION.SDK_INT>=33){ArrayList<String> asks=new ArrayList<>();if(checkSelfPermission(android.Manifest.permission.READ_MEDIA_AUDIO)!=android.content.pm.PackageManager.PERMISSION_GRANTED)asks.add(android.Manifest.permission.READ_MEDIA_AUDIO);if(checkSelfPermission(android.Manifest.permission.READ_MEDIA_VIDEO)!=android.content.pm.PackageManager.PERMISSION_GRANTED)asks.add(android.Manifest.permission.READ_MEDIA_VIDEO);if(!asks.isEmpty())requestPermissions(asks.toArray(new String[0]),733);}else if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)!=android.content.pm.PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE},733);}}
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void pad(View v,int a,int b,int c,int d){v.setPadding(dp(a),dp(b),dp(c),dp(d));}
    TextView button(String s,int color,Runnable action){TextView t=text(s,14,Color.WHITE,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(12),dp(13),dp(12),dp(13));t.setBackground(bg(color,16));t.setOnClickListener(v->action.run());return t;}
    void show(String p){page=p; root=col();root.setBackgroundColor(pale);setContentView(root);
        ScrollView scroll=new ScrollView(this); body=col();pad(body,18,18,18,12);scroll.addView(body,new ScrollView.LayoutParams(-1,-2));root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if(p.equals("Home"))home();else if(p.equals("Video"))video();else if(p.equals("Music"))music();else if(p.equals("Process"))process();else storage();
        makeNav();
    }
    void header(String title,String sub){TextView h=text(title,27,ink,true);body.addView(h);TextView s=text(sub,14,muted,false);body.addView(s);space(body,14);}
    void space(LinearLayout l,int h){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    void card(LinearLayout parent, View child){LinearLayout c=col();pad(c,14,14,14,14);c.setBackground(bg(Color.WHITE,22));c.addView(child);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(12);parent.addView(c,lp);}
    void home(){
        header("Good morning ☀️","Your all-in-one video & music downloader");
        LinearLayout hero=col();pad(hero,18,18,18,18);hero.setBackground(bg(navy,24));
        TextView ht=text("Download Videos\n& Music from Any Link",24,Color.WHITE,true);hero.addView(ht);
        TextView platforms=text("YouTube  ·  Facebook  ·  TikTok / 抖音",13,Color.LTGRAY,false);hero.addView(platforms);space(hero,12);
        card(body,hero);
        inputCard();
        LinearLayout platformsRow=row();
        for(String s:new String[]{"▶ YouTube","f Facebook","♪ TikTok","••• More"}){TextView t=text(s,12,ink,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(5),dp(14),dp(5),dp(14));platformsRow.addView(t,new LinearLayout.LayoutParams(0,-2,1));}
        card(body,platformsRow);
        header("Quick tools","Choose what you want to save");
        LinearLayout r=row();r.addView(button("▣  Video",blue,()->show("Video")),new LinearLayout.LayoutParams(0,-2,1));space(r,1);r.addView(button("♫  Music",purple,()->show("Music")),new LinearLayout.LayoutParams(0,-2,1));card(body,r);
        LinearLayout r2=row();r2.addView(button("☷  Process",navy,()->show("Process")),new LinearLayout.LayoutParams(0,-2,1));r2.addView(button("▤  Storage",muted,()->show("Storage")),new LinearLayout.LayoutParams(0,-2,1));card(body,r2);
    }
    void inputCard(){
        LinearLayout c=col();pad(c,12,12,12,12);c.setBackground(bg(Color.WHITE,20));
        linkInput=new EditText(this);linkInput.setSingleLine(true);linkInput.setTextSize(14);linkInput.setHint("Paste link here (YouTube, Facebook, 抖音...)");linkInput.setPadding(dp(12),dp(10),dp(12),dp(10));linkInput.setBackground(bg(pale,14));c.addView(linkInput,new LinearLayout.LayoutParams(-1,dp(50)));
        space(c,10);LinearLayout r=row();r.addView(button("▣ Paste",0xffe8eef7,()->paste()),new LinearLayout.LayoutParams(0,-2,1));((TextView)r.getChildAt(0)).setTextColor(ink);
        TextView dl=button("↓  Download",blue,()->addLink());LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.leftMargin=dp(8);r.addView(dl,lp);c.addView(r);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=dp(14);body.addView(c,cp);
    }
    void paste(){try{ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);ClipData d=cm.getPrimaryClip();if(d!=null&&d.getItemCount()>0)linkInput.setText(d.getItemAt(0).coerceToText(this));}catch(Exception e){}}
    void addLink(){
        String url=linkInput==null?"":linkInput.getText().toString().trim();
        if(url.isEmpty()){Toast.makeText(this,"Paste a video or audio link first",Toast.LENGTH_SHORT).show();return;}
        if(!url.startsWith("https://")&&!url.startsWith("http://")){Toast.makeText(this,"Please enter a valid http/https link",Toast.LENGTH_SHORT).show();return;}
        queue.add(url);Toast.makeText(this,"Added to Process queue",Toast.LENGTH_SHORT).show();linkInput.setText("");show("Process");
    }
    void video(){header("Video Library","Play downloaded videos offline");inputCard();chips("MY VIDEOS · OFFLINE PLAYBACK");showMediaLibrary(false);header("Download quality","Quality depends on the source link");for(String q:new String[]{"4K (2160p) · MP4","1440p (2K) · MP4","1080p Full HD · MP4","720p HD · MP4","480p · MP4"}){LinearLayout r=row();r.addView(text(q,14,ink,true),new LinearLayout.LayoutParams(0,-2,1));r.addView(button("↓",blue,()->Toast.makeText(this,"Quality selection works only when the source/downloader provides those formats. Direct URLs download their existing quality.",Toast.LENGTH_LONG).show()));card(body,r);}}
    void music(){
        header("Music Library","Listen offline — even with the screen locked");
        LinearLayout c=col();pad(c,12,12,12,12);c.setBackground(bg(Color.WHITE,20));
        TextView hint=text("Download a direct audio file (.mp3, .m4a, .wav, .ogg, .aac or .flac)",12,muted,false);c.addView(hint);
        EditText audioUrl=new EditText(this);audioUrl.setSingleLine(true);audioUrl.setTextSize(14);audioUrl.setHint("https://example.com/song.mp3");audioUrl.setPadding(dp(12),dp(10),dp(12),dp(10));audioUrl.setBackground(bg(pale,14));c.addView(audioUrl,new LinearLayout.LayoutParams(-1,dp(50)));
        space(c,10);LinearLayout actions=row();
        TextView paste=button("▣ Paste",0xffe8eef7,()->{try{ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);ClipData d=cm.getPrimaryClip();if(d!=null&&d.getItemCount()>0)audioUrl.setText(d.getItemAt(0).coerceToText(this));}catch(Exception ignored){}});paste.setTextColor(ink);actions.addView(paste,new LinearLayout.LayoutParams(0,-2,1));
        TextView dl=button("↓ Download music",purple,()->downloadAudioUrl(audioUrl.getText().toString().trim()));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,-2,1);ap.leftMargin=dp(8);actions.addView(dl,ap);c.addView(actions);card(body,c);
        LinearLayout controls=row();controls.addView(button("⏮ Previous",navy,()->sendPlayerAction(PlayerService.ACTION_PREVIOUS)),new LinearLayout.LayoutParams(0,-2,1));controls.addView(button("▶ / Ⅱ",blue,()->sendPlayerAction(PlayerService.ACTION_TOGGLE)),new LinearLayout.LayoutParams(0,-2,1));controls.addView(button("Next ⏭",purple,()->sendPlayerAction(PlayerService.ACTION_NEXT)),new LinearLayout.LayoutParams(0,-2,1));card(body,controls);
        body.addView(button("Shuffle playlist",navy,()->{ArrayList<File> files=mediaFiles(false);if(files.isEmpty()){Toast.makeText(this,"No downloaded songs found yet",Toast.LENGTH_SHORT).show();return;}Collections.shuffle(files);playFiles(files,0);}),new LinearLayout.LayoutParams(-1,-2));
        chips("YOUR SONGS · BACKGROUND PLAYBACK ENABLED");showMediaLibrary(true);
        TextView note=text("Music plays through an Android media service with lock-screen and notification controls. Add downloaded files to Music or Downloads. Direct audio URLs are supported; platform webpage links need a compatible permitted resolver.",12,muted,false);card(body,note);
        header("Sleep timer","Stop playback after a chosen time");LinearLayout timers=row();for(int minutes:new int[]{30,60,90}){timers.addView(button(minutes+" min",navy,()->startSleepTimer(minutes)),new LinearLayout.LayoutParams(0,-2,1));}card(body,timers);
        body.addView(button("Cancel sleep timer",0xff6b7890,()->{if(sleepTimer!=null){sleepTimer.removeCallbacksAndMessages(null);sleepTimer=null;Toast.makeText(this,"Sleep timer cancelled",Toast.LENGTH_SHORT).show();}else Toast.makeText(this,"No active timer",Toast.LENGTH_SHORT).show();}));
    }
    ArrayList<File> mediaFiles(boolean audio){ArrayList<File> out=new ArrayList<>();File[] dirs={Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC),Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)};for(File d:dirs){File[] fs=d.listFiles();if(fs==null)continue;for(File f:fs){if(!f.isFile())continue;String n=f.getName().toLowerCase(Locale.ROOT);boolean a=n.endsWith(".mp3")||n.endsWith(".m4a")||n.endsWith(".wav")||n.endsWith(".ogg")||n.endsWith(".aac")||n.endsWith(".flac");boolean v=n.endsWith(".mp4")||n.endsWith(".mkv")||n.endsWith(".webm")||n.endsWith(".mov")||n.endsWith(".3gp");if(audio?a:v)out.add(f);}}Collections.sort(out,(a,b)->Long.compare(b.lastModified(),a.lastModified()));return out;}
    void showMediaLibrary(boolean audio){ArrayList<File> files=mediaFiles(audio);if(files.isEmpty()){TextView empty=text(audio?"No songs found yet. Download audio or copy music files into Music/Downloads.":"No videos found yet. Download a video or copy video files into Movies/Downloads.",13,muted,false);pad(empty,12,16,12,16);card(body,empty);return;}for(int i=0;i<files.size()&&i<100;i++){File f=files.get(i);final int index=i;LinearLayout r=row();r.addView(text((audio?"♫  ":"▶  ")+f.getName(),14,ink,true),new LinearLayout.LayoutParams(0,-2,1));r.addView(text(android.text.format.Formatter.formatFileSize(this,f.length()),10,muted,false));r.setOnClickListener(v->playFiles(files,index));card(body,r);}}
    void playFiles(ArrayList<File> files,int index){if(files.isEmpty())return;if(!isAudioFile(files.get(index))){try{Intent view=new Intent(Intent.ACTION_VIEW);view.setDataAndType(Uri.fromFile(files.get(index)),"video/*");view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(view);}catch(Exception e){Toast.makeText(this,"No compatible video player found",Toast.LENGTH_LONG).show();}return;}ArrayList<String> paths=new ArrayList<>();for(File f:files)paths.add(f.getAbsolutePath());Intent i=new Intent(this,PlayerService.class);i.setAction(PlayerService.ACTION_PLAY_LIST);i.putStringArrayListExtra(PlayerService.EXTRA_LIST,paths);i.putExtra(PlayerService.EXTRA_INDEX,index);try{if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);Toast.makeText(this,"Starting playback. Lock-screen controls are available.",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Could not start player: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
    boolean isAudioFile(File f){String n=f.getName().toLowerCase(Locale.ROOT);return n.endsWith(".mp3")||n.endsWith(".m4a")||n.endsWith(".wav")||n.endsWith(".ogg")||n.endsWith(".aac")||n.endsWith(".flac");}
    void sendPlayerAction(String action){Intent i=new Intent(this,PlayerService.class);i.setAction(action);try{startService(i);}catch(Exception e){Toast.makeText(this,"Start a song first",Toast.LENGTH_SHORT).show();}}
    android.os.Handler sleepTimer;
    void startSleepTimer(int minutes){
        if(sleepTimer!=null)sleepTimer.removeCallbacksAndMessages(null);
        sleepTimer=new android.os.Handler();
        sleepTimer.postDelayed(()->{
            try{Intent i=new Intent("com.android.music.musicservicecommand");i.putExtra("command","pause");sendBroadcast(i);}catch(Exception ignored){}
            Toast.makeText(this,"Sleep timer finished. If your player doesn't respond, use its own sleep timer.",Toast.LENGTH_LONG).show();
            sleepTimer=null;
        },minutes*60L*1000L);
        Toast.makeText(this,"Sleep timer set for "+minutes+" minutes",Toast.LENGTH_SHORT).show();
    }
    void downloadAudioUrl(String url){
        if(url.isEmpty()){Toast.makeText(this,"Paste a direct audio URL first",Toast.LENGTH_SHORT).show();return;}
        if(!url.startsWith("https://")&&!url.startsWith("http://")){Toast.makeText(this,"Please enter a valid http/https URL",Toast.LENGTH_SHORT).show();return;}
        String low=url.toLowerCase(Locale.ROOT);
        String ext=null;
        for(String e:new String[]{".mp3",".m4a",".wav",".ogg",".aac",".flac"})if(low.matches(".*"+e+"([?#].*)?$")){ext=e;break;}
        if(ext==null){Toast.makeText(this,"This URL does not look like a direct audio file. Platform links need a permitted resolver.",Toast.LENGTH_LONG).show();return;}
        try{
            DownloadManager.Request req=new DownloadManager.Request(Uri.parse(url));
            req.setTitle("MediaLink music");req.setDescription("Saving audio for offline listening");
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_MUSIC,"MediaLink_"+System.currentTimeMillis()+ext);
            long id=((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(req);
            Toast.makeText(this,"Music download started. Check Android notifications or Storage.",Toast.LENGTH_LONG).show();
        }catch(Exception e){Toast.makeText(this,"Download failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    void chips(String s){TextView t=text(s,12,navy,true);pad(t,12,12,12,12);t.setBackground(bg(0xffe5edfa,16));body.addView(t);space(body,12);}
    void process(){header("Process","Downloading, converting and completed");
        LinearLayout tabs=row();for(String s:new String[]{"All ("+(queue.size()+completed.size())+")","Downloading","Completed"}){TextView t=text(s,12,ink,true);t.setGravity(Gravity.CENTER);tabs.addView(t,new LinearLayout.LayoutParams(0,dp(42),1));}card(body,tabs);
        if(queue.isEmpty()&&completed.isEmpty()){TextView empty=text("No downloads yet\nPaste a link on Home, Video or Music to add it here.",15,muted,false);pad(empty,12,28,12,28);card(body,empty);}
        for(String url:queue){LinearLayout item=col();item.addView(text("⬇  "+shortUrl(url),15,ink,true));item.addView(text("Waiting in queue  ·  Ready when supported",12,muted,false));space(item,8);ProgressBar pb=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);pb.setProgress(0);item.addView(pb);space(item,8);item.addView(button("Try direct download",blue,()->downloadDirect(url)));card(body,item);}
        for(String f:completed){LinearLayout item=col();item.addView(text("✓  "+f,15,ink,true));item.addView(text("Completed",12,0xff14804a,false));card(body,item);}
        TextView note=text("Note: platform page links require a compliant resolver. Direct .mp4/.mp3 URLs can be downloaded by Android Download Manager.",12,muted,false);body.addView(note);
    }
    String shortUrl(String s){return s.length()>44?s.substring(0,41)+"...":s;}
    void downloadDirect(String url){
        String low=url.toLowerCase(Locale.ROOT);
        if(!(low.contains(".mp4")||low.contains(".mp3")||low.contains(".m4a")||low.contains(".webm")||low.contains(".wav")||low.contains(".mov"))){Toast.makeText(this,"This looks like a platform page, not a direct media file. A resolver service is needed.",Toast.LENGTH_LONG).show();return;}
        try{DownloadManager.Request req=new DownloadManager.Request(Uri.parse(url));req.setTitle("MediaLink download");req.setDescription("Downloading media");req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "MediaLink_"+System.currentTimeMillis()+guessExt(low));((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(req);queue.remove(url);completed.add("MediaLink_"+(completed.size()+1)+guessExt(low));Toast.makeText(this,"Download started in Android Download Manager",Toast.LENGTH_LONG).show();show("Process");}catch(Exception e){Toast.makeText(this,"Could not start download: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    String guessExt(String s){for(String e:new String[]{".mp4",".mp3",".m4a",".webm",".wav",".mov"})if(s.contains(e))return e;return ".bin";}
    void storage(){header("Storage","Manage your downloaded files");File d=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);long total=0;try{if(d.exists())for(File f:d.listFiles())if(f.isFile())total+=f.length();}catch(Exception e){}
        LinearLayout summary=col();summary.addView(text("Downloads folder",17,ink,true));summary.addView(text(d.getAbsolutePath(),12,muted,false));space(summary,8);summary.addView(text("Files found: "+(d.exists()&&d.listFiles()!=null?d.listFiles().length:0),14,blue,true));summary.addView(text("Used by visible files: "+android.text.format.Formatter.formatFileSize(this,total),14,muted,false));card(body,summary);
        body.addView(text("Recent files",18,ink,true));space(body,8);
        File[] list=d.listFiles();if(list!=null){Arrays.sort(list,(a,b)->Long.compare(b.lastModified(),a.lastModified()));int count=0;for(File f:list){if(!f.isFile())continue;LinearLayout r=row();r.addView(text(iconFor(f.getName())+"  "+f.getName(),14,ink,true),new LinearLayout.LayoutParams(0,-2,1));r.addView(text(android.text.format.Formatter.formatFileSize(this,f.length()),11,muted,false));card(body,r);if(++count>=30)break;}}
        if(list==null||list.length==0)card(body,text("Your downloaded files will appear here.",14,muted,false));
        body.addView(button("Open Android Downloads",blue,()->{try{Intent i=new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS);startActivity(i);}catch(Exception e){Toast.makeText(this,"Open the Files app to view Downloads",Toast.LENGTH_SHORT).show();}}));
    }
    String iconFor(String n){String x=n.toLowerCase(Locale.ROOT);if(x.endsWith(".mp3")||x.endsWith(".m4a")||x.endsWith(".wav"))return "♫";if(x.endsWith(".mp4")||x.endsWith(".mov")||x.endsWith(".webm"))return "▶";return "▤";}
    void makeNav(){nav=row();nav.setBackgroundColor(Color.WHITE);String[] labels={"Home","Video","Music","Process","Storage"};String[] icons={"⌂","▣","♫","☷","▤"};for(int i=0;i<labels.length;i++){final String dest=labels[i];LinearLayout cell=col();cell.setGravity(Gravity.CENTER);TextView ic=text(icons[i],19,page.equals(dest)?blue:muted,true);ic.setGravity(Gravity.CENTER);TextView tx=text(labels[i],10,page.equals(dest)?blue:muted,page.equals(dest));tx.setGravity(Gravity.CENTER);cell.addView(ic);cell.addView(tx);cell.setPadding(0,dp(8),0,dp(8));cell.setOnClickListener(v->show(dest));nav.addView(cell,new LinearLayout.LayoutParams(0,-2,1));}root.addView(nav);}
}
