package com.example.helloworld;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TextView hello = new TextView(this);
        hello.setText("Hello World!");
        hello.setTextSize(32);
        hello.setTextColor(Color.BLACK);
        hello.setGravity(Gravity.CENTER);
        hello.setBackgroundColor(Color.WHITE);

        setContentView(hello);
    }
}
