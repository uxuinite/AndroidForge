Hello World Android app

This is a minimal Android Studio project written in Java.
It displays "Hello World!" on a white screen.

To build an APK:
1. Open this folder in Android Studio.
2. Allow Gradle sync to finish (internet may be required to download Android Gradle Plugin).
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Find the APK at app/build/outputs/apk/debug/app-debug.apk

Package ID: com.example.helloworld
Minimum Android: Android 6.0 (API 23)
