AI Video Audio Suite — Android project ZIP

This is a native Android Java UI prototype based on the agreed dark/neon design.
Included: home dashboard, navigation, video picker, Demucs separation options,
transcription language options (Auto/English/Chinese/Khmer), transcript preview,
VoxCPM2 text input screen, settings, and placeholder interactions.

IMPORTANT: AI engines are NOT connected in this project yet. Demucs, FFmpeg video
processing, Whisper transcription, VoxCPM2 speech generation, and TXT/SRT/WAV/MP4
exports require a compatible runtime or processing server and further integration.
Buttons clearly report that these functions are not yet connected.

Build using AndroidForge:
1. Upload this ZIP to AndroidForge.
2. Choose the debug APK build option if prompted.
3. No Android NDK is needed for this Java-only UI prototype.
4. Download the APK artifact and install it on your Android phone.

Package: com.example.aivideoaudiosuite
Minimum Android: 8.0 (API 26)
