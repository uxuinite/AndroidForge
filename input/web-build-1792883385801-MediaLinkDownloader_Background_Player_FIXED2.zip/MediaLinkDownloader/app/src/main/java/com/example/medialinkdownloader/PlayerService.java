package com.example.medialinkdownloader;

import android.app.*;
import android.content.*;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.net.Uri;
import androidx.annotation.Nullable;
import androidx.media.app.NotificationCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import java.io.File;
import java.util.ArrayList;

public class PlayerService extends Service {
    public static final String ACTION_PLAY_LIST="com.example.medialinkdownloader.PLAY_LIST";
    public static final String ACTION_TOGGLE="com.example.medialinkdownloader.TOGGLE";
    public static final String ACTION_NEXT="com.example.medialinkdownloader.NEXT";
    public static final String ACTION_PREVIOUS="com.example.medialinkdownloader.PREVIOUS";
    public static final String EXTRA_LIST="playlist_paths";
    public static final String EXTRA_INDEX="playlist_index";
    private static final String CHANNEL="medialink_playback";
    private MediaPlayer player;
    private MediaSessionCompat session;
    private ArrayList<String> playlist=new ArrayList<>();
    private int index=0;
    private boolean repeatAll=true;
    private boolean repeatOne=false;
    private int notificationId=4210;

    @Override public void onCreate(){super.onCreate();createChannel();session=new MediaSessionCompat(this,"MediaLinkPlayer");session.setCallback(new MediaSessionCompat.Callback(){
        @Override public void onPlay(){resume();}
        @Override public void onPause(){pause();}
        @Override public void onSkipToNext(){next();}
        @Override public void onSkipToPrevious(){previous();}
        @Override public void onStop(){stopPlayback();}
        @Override public void onSetRepeatMode(int mode){repeatOne=mode==PlaybackStateCompat.REPEAT_MODE_ONE;repeatAll=mode==PlaybackStateCompat.REPEAT_MODE_ALL;updateState();}
    });session.setFlags(MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS|MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS);session.setActive(true);}
    @Override public int onStartCommand(Intent intent,int flags,int startId){if(intent==null){if(player!=null)showNotification();return START_NOT_STICKY;}String a=intent.getAction();if(ACTION_PLAY_LIST.equals(a)){ArrayList<String> list=intent.getStringArrayListExtra(EXTRA_LIST);if(list!=null){playlist=list;index=Math.max(0,Math.min(intent.getIntExtra(EXTRA_INDEX,0),playlist.size()-1));playCurrent();}}else if(ACTION_TOGGLE.equals(a)){if(player!=null&&player.isPlaying())pause();else resume();}else if(ACTION_NEXT.equals(a))next();else if(ACTION_PREVIOUS.equals(a))previous();return START_NOT_STICKY;}
    private void playCurrent(){if(playlist.isEmpty()){stopSelf();return;}releasePlayer();try{File f=new File(playlist.get(index));player=new MediaPlayer();player.setWakeMode(this,PowerManager.PARTIAL_WAKE_LOCK);player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(isAudio(f)?AudioAttributes.CONTENT_TYPE_MUSIC:AudioAttributes.CONTENT_TYPE_MOVIE).build());player.setDataSource(this,Uri.fromFile(f));player.setOnPreparedListener(mp->{mp.start();updateMetadata(f);updateState();showNotification();});player.setOnCompletionListener(mp->{if(repeatOne){playCurrent();}else if(index<playlist.size()-1){index++;playCurrent();}else if(repeatAll){index=0;playCurrent();}else{updateState();showNotification();stopForeground(false);}});player.setOnErrorListener((mp,what,extra)->{next();return true;});player.prepareAsync();startForeground(notificationId,buildNotification(f));}catch(Exception e){next();}}
    private boolean isAudio(File f){String n=f.getName().toLowerCase();return n.endsWith(".mp3")||n.endsWith(".m4a")||n.endsWith(".wav")||n.endsWith(".ogg")||n.endsWith(".aac")||n.endsWith(".flac");}
    private void resume(){if(player!=null){try{player.start();updateState();showNotification();}catch(Exception ignored){}}else if(!playlist.isEmpty())playCurrent();}
    private void pause(){if(player!=null&&player.isPlaying()){player.pause();updateState();showNotification();}}
    private void next(){if(playlist.isEmpty())return;if(index<playlist.size()-1)index++;else if(repeatAll)index=0;else{pause();return;}playCurrent();}
    private void previous(){if(playlist.isEmpty())return;if(player!=null&&player.getCurrentPosition()>3000){player.seekTo(0);return;}if(index>0)index--;else if(repeatAll)index=playlist.size()-1;playCurrent();}
    private void stopPlayback(){releasePlayer();stopForeground(true);stopSelf();}
    private void releasePlayer(){if(player!=null){try{player.reset();player.release();}catch(Exception ignored){}player=null;}}
    private void updateMetadata(File f){session.setMetadata(new MediaMetadataCompat.Builder().putString(MediaMetadataCompat.METADATA_KEY_TITLE, f.getName()).putString(MediaMetadataCompat.METADATA_KEY_ARTIST, "MediaLink Downloader").putLong(MediaMetadataCompat.METADATA_KEY_DURATION, player==null?0:player.getDuration()).build());}
    private void updateState(){long actions=PlaybackStateCompat.ACTION_PLAY|PlaybackStateCompat.ACTION_PAUSE|PlaybackStateCompat.ACTION_PLAY_PAUSE|PlaybackStateCompat.ACTION_SKIP_TO_NEXT|PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS|PlaybackStateCompat.ACTION_STOP|PlaybackStateCompat.ACTION_SEEK_TO;int state=player!=null&&player.isPlaying()?PlaybackStateCompat.STATE_PLAYING:PlaybackStateCompat.STATE_PAUSED;long pos=0;try{if(player!=null)pos=player.getCurrentPosition();}catch(Exception ignored){}session.setPlaybackState(new PlaybackStateCompat.Builder().setActions(actions).setState(state,pos,player!=null&&player.isPlaying()?1f:0f).build());}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel(CHANNEL,"MediaLink playback",NotificationManager.IMPORTANCE_LOW);ch.setDescription("Playback controls for music and videos");((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);}}
    private Notification buildNotification(File f){Intent open=new Intent(this,MainActivity.class);PendingIntent content=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);PendingIntent prev=servicePending(ACTION_PREVIOUS,1),toggle=servicePending(ACTION_TOGGLE,2),next=servicePending(ACTION_NEXT,3);boolean playing=player!=null&&player.isPlaying();androidx.core.app.NotificationCompat.Builder b=new androidx.core.app.NotificationCompat.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_media_play).setContentTitle(f.getName()).setContentText("MediaLink · background playback").setContentIntent(content).setOngoing(playing).setVisibility(androidx.core.app.NotificationCompat.VISIBILITY_PUBLIC).addAction(android.R.drawable.ic_media_previous,"Previous",prev).addAction(playing?android.R.drawable.ic_media_pause:android.R.drawable.ic_media_play,playing?"Pause":"Play",toggle).addAction(android.R.drawable.ic_media_next,"Next",next);if(session!=null)b.setStyle(new NotificationCompat.MediaStyle().setMediaSession(session.getSessionToken()).setShowActionsInCompactView(0,1,2));return b.build();}
    private PendingIntent servicePending(String action,int code){Intent i=new Intent(this,PlayerService.class);i.setAction(action);return PendingIntent.getService(this,code,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    private void showNotification(){if(playlist.isEmpty())return;File f=new File(playlist.get(index));updateState();((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(notificationId,buildNotification(f));}
    @Override public void onTaskRemoved(Intent rootIntent){if(player==null||!player.isPlaying())stopSelf();}
    @Override public void onDestroy(){releasePlayer();if(session!=null){session.setActive(false);session.release();}super.onDestroy();}
    @Nullable @Override public IBinder onBind(Intent intent){return null;}
}
