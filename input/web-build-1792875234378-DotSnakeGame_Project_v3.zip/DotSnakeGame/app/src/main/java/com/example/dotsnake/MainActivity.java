package com.example.dotsnake;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.RectF;
import android.view.View;
import android.view.MotionEvent;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.view.Window;
import android.view.WindowManager;
import android.graphics.PointF;
import java.util.ArrayDeque;
import java.util.Random;
import java.util.Iterator;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Window w=getWindow();
        w.setStatusBarColor(Color.rgb(4,8,18));
        w.setNavigationBarColor(Color.rgb(4,8,18));
        w.getDecorView().setSystemUiVisibility(0);
        GameView game = new GameView(this);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(4,8,18));
        root.addView(game, new FrameLayout.LayoutParams(-1,-1));
        // Keep content below the status bar and above the gesture/navigation bar.
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = insets.getSystemWindowInsetTop();
            int bottom = insets.getSystemWindowInsetBottom();
            v.setPadding(0, top, 0, bottom);
            return insets;
        });
        setContentView(root);
        root.requestApplyInsets();
    }

    static class GameView extends View {
        final Paint p=new Paint(3);
        final Random random=new Random();
        final ArrayDeque<PointF> snake=new ArrayDeque<>();
        final int bg=Color.rgb(3,9,21), blue=Color.rgb(0,168,255), cyan=Color.rgb(0,239,255), purple=Color.rgb(174,47,255);
        float downX,downY,cell=32, boardTop, boardBottom;
        int cols=12, rows=20, dx=1,dy=0, score=0, best=0;
        PointF food=new PointF(5,8); ArrayDeque<Food> foods=new ArrayDeque<>();
        long lastMove=0;
        boolean started=false, paused=false, over=false, showMenu=true;
        MainActivity activity;

        GameView(MainActivity a){super(a);activity=a;setLayerType(View.LAYER_TYPE_SOFTWARE,null);setFocusable(true);}

        void reset(){
            snake.clear(); foods.clear(); int cx=cols/2, cy=rows/2;
            for(int i=3;i>=0;i--) snake.add(new PointF(cx-i,cy));
            dx=1;dy=0;score=0;over=false;paused=false;started=true;showMenu=false;for(int k=0;k<32;k++)placeFood();invalidate();
        }
        static class Food { PointF pos; int color; long phase; Food(float x,float y,int c,long ph){pos=new PointF(x,y);color=c;phase=ph;} }
        int[] foodColors={Color.rgb(255,145,35),Color.rgb(65,255,125),Color.rgb(184,70,255),Color.rgb(0,235,255),Color.rgb(255,213,45)};
        void placeFood(){
            for(int tries=0;tries<100;tries++){
                PointF f=new PointF(random.nextInt(Math.max(1,cols)),random.nextInt(Math.max(1,rows)));
                boolean hit=false;
                for(PointF sn:snake)if(sn.x==f.x&&sn.y==f.y){hit=true;break;}
                for(Food fd:foods)if(fd.pos.x==f.x&&fd.pos.y==f.y){hit=true;break;}
                if(!hit){foods.add(new Food(f.x,f.y,foodColors[random.nextInt(foodColors.length)],random.nextInt(2000)));return;}
            }
        }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c); float w=getWidth(),h=getHeight();
            c.drawColor(bg);
            // Background glow
            p.setShader(new LinearGradient(0,0,w,h,Color.rgb(3,15,38),Color.rgb(5,3,22),Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,p);p.setShader(null);
            float pad=18, headerH=125, footerH=96;
            float boardLeft=pad, boardRight=w-pad;
            boardTop=headerH; boardBottom=h-footerH;
            float boardW=boardRight-boardLeft, boardH=boardBottom-boardTop;
            cols=Math.max(5,(int)(boardW/65)); rows=Math.max(8,(int)(boardH/65));
            cell=Math.min(boardW/cols,boardH/rows);
            float actualW=cols*cell, actualH=rows*cell;
            boardLeft=(w-actualW)/2; boardTop=headerH+(boardH-actualH)/2;
            // Top title with safe padding
            p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.create("sans-serif-black",Typeface.BOLD));
            p.setTextSize(Math.min(39,w*.105f));
            p.setShader(new LinearGradient(w*.2f,0,w*.8f,0,cyan,purple,Shader.TileMode.CLAMP));
            c.drawText("DOT SNAKE",w/2,45,p);p.setShader(null);
            p.setTextSize(14);p.setTypeface(Typeface.DEFAULT);p.setColor(Color.rgb(125,199,255));
            c.drawText("SWIPE TO TURN • WRAP THROUGH EDGES",w/2,68,p);
            // Score cards
            rounded(c,w*.12f,80,w*.48f,119,14,Color.rgb(7,21,42),Color.rgb(15,62,105));
            rounded(c,w*.52f,80,w*.88f,119,14,Color.rgb(7,21,42),Color.rgb(15,62,105));
            p.setTextSize(12);p.setColor(Color.LTGRAY);c.drawText("SCORE",w*.30f,96,p);
            p.setTextSize(21);p.setTypeface(Typeface.DEFAULT_BOLD);p.setColor(cyan);c.drawText(""+score,w*.30f,114,p);
            p.setTextSize(12);p.setColor(Color.LTGRAY);p.setTypeface(Typeface.DEFAULT);c.drawText("BEST",w*.70f,96,p);
            p.setTextSize(21);p.setTypeface(Typeface.DEFAULT_BOLD);p.setColor(Color.rgb(255,205,65));c.drawText(""+Math.max(best,score),w*.70f,114,p);
            // dotted board
            for(int r=0;r<rows;r++)for(int co=0;co<cols;co++){
                p.setColor(Color.argb(100,0,118,230));c.drawCircle(boardLeft+(co+.5f)*cell,boardTop+(r+.5f)*cell,Math.max(1.3f,cell*.07f),p);
            }
            // Multicolour food pulses smoothly from dim to bright and back every 2 seconds.
            long pulseTime=System.currentTimeMillis();
            for(Food fd:foods){
                float fx=boardLeft+(fd.pos.x+.5f)*cell, fy=boardTop+(fd.pos.y+.5f)*cell;
                double wave=(Math.sin(((pulseTime+fd.phase)%2000L)*Math.PI*2.0/2000.0)+1.0)/2.0;
                float brightness=(float)(0.22+0.78*wave);
                int alpha=(int)(70+185*brightness);
                int glowing=Color.argb(alpha,Color.red(fd.color),Color.green(fd.color),Color.blue(fd.color));
                float glowRadius=cell*(0.08f+0.42f*brightness);
                p.setShadowLayer(glowRadius,0,0,glowing);
                p.setColor(Color.argb((int)(100+155*brightness),Color.red(fd.color),Color.green(fd.color),Color.blue(fd.color)));
                c.drawCircle(fx,fy,cell*.27f,p);
                p.clearShadowLayer();
                p.setColor(Color.argb((int)(30+190*brightness),255,255,255));
                c.drawCircle(fx-cell*.07f,fy-cell*.07f,cell*.065f,p);
            }
            // snake
            int i=0;for(PointF s:snake){
                float x=boardLeft+(s.x+.5f)*cell,y=boardTop+(s.y+.5f)*cell;
                int col=i==snake.size()-1?cyan:blue;
                p.setShadowLayer(cell*.38f,0,0,col);p.setColor(col);c.drawCircle(x,y,cell*.47f,p);p.clearShadowLayer();
                if(i==snake.size()-1){p.setColor(Color.WHITE);c.drawCircle(x-cell*.12f,y-cell*.07f,cell*.055f,p);c.drawCircle(x+cell*.12f,y-cell*.07f,cell*.055f,p);}
                i++;
            }
            if(showMenu){overlay(c,w,h,"DOT SNAKE","Swipe in any direction to turn","TAP TO PLAY");}
            else if(over){overlay(c,w,h,"GAME OVER","Score: "+score+"   Best: "+Math.max(best,score),"TAP TO PLAY AGAIN");}
            else if(paused){overlay(c,w,h,"PAUSED","Take a breath","TAP TO RESUME");}
            else {
                p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(14);p.setColor(Color.rgb(120,190,235));
                c.drawText("SWIPE TO TURN • NO WALLS",w/2,h-34,p);
            }
        }
        void rounded(Canvas c,float l,float t,float r,float b,float rad,int fill,int stroke){
            p.setColor(fill);p.setStyle(Paint.Style.FILL);c.drawRoundRect(new RectF(l,t,r,b),rad,rad,p);
            p.setColor(stroke);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.5f);c.drawRoundRect(new RectF(l,t,r,b),rad,rad,p);p.setStyle(Paint.Style.FILL);
        }
        void overlay(Canvas c,float w,float h,String title,String sub,String action){
            p.setColor(Color.argb(190,1,5,15));c.drawRect(0,125,w,h-95,p);
            p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(Math.min(30,w*.08f));p.setColor(Color.WHITE);c.drawText(title,w/2,h*.43f,p);
            p.setTypeface(Typeface.DEFAULT);p.setTextSize(15);p.setColor(Color.rgb(155,220,255));c.drawText(sub,w/2,h*.43f+30,p);
            float bw=w*.72f,bh=54,l=(w-bw)/2,top=h*.43f+55;
            p.setShader(new LinearGradient(l,top,l+bw,top+bh,blue,purple,Shader.TileMode.CLAMP));c.drawRoundRect(new RectF(l,top,l+bw,top+bh),18,18,p);p.setShader(null);
            p.setTextSize(16);p.setTypeface(Typeface.DEFAULT_BOLD);p.setColor(Color.WHITE);c.drawText(action,w/2,top+33,p);
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()==MotionEvent.ACTION_DOWN){downX=e.getX();downY=e.getY();return true;}
            if(e.getAction()==MotionEvent.ACTION_UP){
                float sx=e.getX()-downX,sy=e.getY()-downY;
                if(showMenu||over){reset();return true;}
                if(paused){paused=false;invalidate();return true;}
                if(Math.abs(sx)<24&&Math.abs(sy)<24){paused=true;invalidate();return true;}
                if(Math.abs(sx)>Math.abs(sy)){
                    if(sx>0&&dx!=-1){dx=1;dy=0;}else if(sx<0&&dx!=1){dx=-1;dy=0;}
                }else{
                    if(sy>0&&dy!=-1){dx=0;dy=1;}else if(sy<0&&dy!=1){dx=0;dy=-1;}
                }
                invalidate();return true;
            }return true;
        }
        @Override protected void onAttachedToWindow(){super.onAttachedToWindow();post(tick);}
        @Override protected void onDetachedFromWindow(){removeCallbacks(tick);super.onDetachedFromWindow();}
        Runnable tick=new Runnable(){public void run(){
            if(started&&!paused&&!over&&getWidth()>0){
                long now=System.currentTimeMillis();
                if(now-lastMove>135){
                    lastMove=now;
                    PointF head=snake.peekLast();int nx=(int)head.x+dx,ny=(int)head.y+dy;
                    // Wrap through screen edges instead of hitting walls
                    if(nx<0)nx=cols-1; if(nx>=cols)nx=0;
                    if(ny<0)ny=rows-1; if(ny>=rows)ny=0;
                    boolean self=false;Iterator<PointF> it=snake.iterator();while(it.hasNext()){PointF sn=it.next();if(sn.x==nx&&sn.y==ny){self=true;break;}}
                    if(self){over=true;best=Math.max(best,score);}
                    else{
                        snake.add(new PointF(nx,ny));
                        boolean ate=false;
                        Iterator<Food> fit=foods.iterator();
                        while(fit.hasNext()){
                            Food fd=fit.next();
                            if(nx==(int)fd.pos.x&&ny==(int)fd.pos.y){fit.remove();score+=10;ate=true;break;}
                        }
                        if(ate)placeFood(); else snake.removeFirst();
                    }
                }
            }
            invalidate();postDelayed(this,35);
        }};
    }
}
