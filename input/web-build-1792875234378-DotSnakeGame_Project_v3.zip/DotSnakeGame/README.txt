DOT SNAKE — Android game project v3

Updates in this version:
- Snake and food are about 3x larger on screen by using a wider-spaced grid.
- 32 multicolour food dots (orange, green, purple, cyan and yellow) are placed across the field.
- Each food dot smoothly fades between dim and bright, with a 2-second pulse cycle and soft glow.
- The snake wraps around screen edges instead of hitting walls.
- Swipe up/down/left/right anywhere in the playfield to steer.
- Eat food to gain 10 points and grow; hitting your own body ends the round.
- Top status bar and bottom navigation/gesture bar spacing retained.

Build:
1. Upload DotSnakeGame_Project_v3.zip to AndroidForge.
2. Select Android (APK), leave Force-install NDK unchecked.
3. Build, then download and install the APK.

Package: com.example.dotsnake
Minimum Android: 6.0 (API 23)
