DOT SNAKE — Android game project

A playable native Java Snake game with neon dot styling.
Controls: swipe up/down/left/right anywhere in the game field to change direction.
Tap to start/restart; tap during play to pause. Score increases when the snake eats the glowing food. Hitting a wall or itself ends the round.

UI fixes:
- App content receives Android system window inset padding, so the title stays below the status bar and game content stays above the bottom gesture/navigation bar.
- Target SDK 34 avoids forced Android 15 edge-to-edge while still using window inset padding.

Build with AndroidForge:
1. Upload DotSnakeGame_Project.zip.
2. Choose Android (APK), build variant auto/debug, leave Force-install NDK unchecked.
3. Build and download the APK artifact.

Package: com.example.dotsnake
Min Android: 6.0 (API 23)
